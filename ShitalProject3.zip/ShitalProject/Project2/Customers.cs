﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Project2
{
    public partial class Customers : Form
    {
        DataTable dt;
        DataColumn dc;
        DataRow dr;
        DataTable cust;
        public Customers()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            cust = Generatetable();
            dataGridView1.DataSource = cust;

        }
        DataTable Generatetable()
        {
            dt = new DataTable("Customers");

            dc = new DataColumn("CustId", typeof(int));
            dt.Columns.Add(dc);
            dt.PrimaryKey = new DataColumn[] { dc };

            dc = new DataColumn("CustName", typeof(string));
            dt.Columns.Add(dc);

            dc = new DataColumn("CustContact", typeof(long));
            dt.Columns.Add(dc);

            dc = new DataColumn("CustAddress", typeof(string));
            dt.Columns.Add(dc);


            dc = new DataColumn("CustDescription", typeof(string));
            dt.Columns.Add(dc);


            return dt;
        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            string custid, custname, custcontact, custemail, custaddress;
            custid = txtcustid.Text;
            custname = txtcustname.Text;
            custcontact = txtcontact.Text;
            custemail = txtcustemail.Text;
            custaddress = txtcustaddress.Text;


            try
            {

                dr = cust.NewRow();
                dr[0] = int.Parse(custid);
                dr[1] = custname;
                dr[2] = long.Parse(custcontact);
                dr[3] = custemail;
                dr[4] = custaddress;

                cust.Rows.Add(dr);
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);

            }
            clear();

        }
        private void clear()
        {

            txtcustid.Text = "";
            txtcustname.Text = "";
            txtcontact.Text = "";
            txtcustemail.Text = "";
            txtcustaddress.Text = "";

        }

        private void txtcustid_TextChanged(object sender, EventArgs e)
        {

            if (Regex.IsMatch(txtcustid.Text, "[^0-9]"))
            {
                MessageBox.Show("do not enter non numeric vals");
                txtcustid.Text = "";

            }

        }

        private void txtcontact_TextChanged(object sender, EventArgs e)
        {
            if (Regex.IsMatch(txtcontact.Text, "[^0-9]"))

            {
                MessageBox.Show("Enter valid Mobile Number");
                txtcontact.Text = "";
            }
        }

       
    }
}


