﻿namespace Project2
{
    partial class Customer_Info
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtcustidinfo = new System.Windows.Forms.TextBox();
            this.txtpayos = new System.Windows.Forms.TextBox();
            this.txtoffercb = new System.Windows.Forms.TextBox();
            this.btnsubmit = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.txtdob = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Chartreuse;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "CUST ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Chartreuse;
            this.label2.Location = new System.Drawing.Point(12, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(131, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "DATE OF BIRTH";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Chartreuse;
            this.label3.Location = new System.Drawing.Point(12, 120);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(222, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "PAYMENT OFFER_SOURCE";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Chartreuse;
            this.label4.Location = new System.Drawing.Point(12, 190);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(165, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "OFFER CASH_BACK";
            // 
            // txtcustidinfo
            // 
            this.txtcustidinfo.Location = new System.Drawing.Point(292, 9);
            this.txtcustidinfo.Name = "txtcustidinfo";
            this.txtcustidinfo.Size = new System.Drawing.Size(291, 26);
            this.txtcustidinfo.TabIndex = 4;
            this.txtcustidinfo.TextChanged += new System.EventHandler(this.txtcustidinfo_TextChanged);
            // 
            // txtpayos
            // 
            this.txtpayos.Location = new System.Drawing.Point(292, 120);
            this.txtpayos.Name = "txtpayos";
            this.txtpayos.Size = new System.Drawing.Size(291, 26);
            this.txtpayos.TabIndex = 6;
            // 
            // txtoffercb
            // 
            this.txtoffercb.Location = new System.Drawing.Point(292, 190);
            this.txtoffercb.Name = "txtoffercb";
            this.txtoffercb.Size = new System.Drawing.Size(291, 26);
            this.txtoffercb.TabIndex = 7;
            // 
            // btnsubmit
            // 
            this.btnsubmit.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnsubmit.ForeColor = System.Drawing.Color.Chartreuse;
            this.btnsubmit.Location = new System.Drawing.Point(292, 252);
            this.btnsubmit.Name = "btnsubmit";
            this.btnsubmit.Size = new System.Drawing.Size(98, 39);
            this.btnsubmit.TabIndex = 8;
            this.btnsubmit.Text = "SUBMIT";
            this.btnsubmit.UseVisualStyleBackColor = false;
            this.btnsubmit.Click += new System.EventHandler(this.btnsubmit_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(16, 312);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(1311, 306);
            this.dataGridView1.TabIndex = 9;
            // 
            // txtdob
            // 
            this.txtdob.Location = new System.Drawing.Point(292, 57);
            this.txtdob.Name = "txtdob";
            this.txtdob.Size = new System.Drawing.Size(291, 26);
            this.txtdob.TabIndex = 10;
            // 
            // Customer_Info
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1339, 630);
            this.Controls.Add(this.txtdob);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnsubmit);
            this.Controls.Add(this.txtoffercb);
            this.Controls.Add(this.txtpayos);
            this.Controls.Add(this.txtcustidinfo);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Customer_Info";
            this.Text = "CUSTOMER_INFO";
            this.Load += new System.EventHandler(this.Form6_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtcustidinfo;
        private System.Windows.Forms.TextBox txtpayos;
        private System.Windows.Forms.TextBox txtoffercb;
        private System.Windows.Forms.Button btnsubmit;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DateTimePicker txtdob;
    }
}