﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project2
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Product ob = new Product();
            ob.Show();
        }
       
        private void button2_Click_1(object sender, EventArgs e)
        {
            Categories ob = new Categories();
            ob.Show();


        }

        private void button3_Click(object sender, EventArgs e)
        {
            Customers ob = new Customers();
            ob.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Orders ob = new Orders();
            ob.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Offers ob = new Offers();
            ob.Show();

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Customer_Info ob = new Customer_Info();
            ob.Show();
        }
    }
}
