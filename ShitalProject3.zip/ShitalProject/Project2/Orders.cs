﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Project2
{
    public partial class Orders : Form
    {
        DataTable dt;
        DataColumn dc;
        DataRow dr;
        DataTable order;
        public Orders()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            order = Generatetable();
            dataGridView1.DataSource = order;
        }
        DataTable Generatetable()
        {
            dt = new DataTable("Orders");

            dc = new DataColumn("OrderId", typeof(int));
            dt.Columns.Add(dc);
            dt.PrimaryKey = new DataColumn[] { dc };

            dc = new DataColumn("ProductId", typeof(int));
            dt.Columns.Add(dc);
            


            dc = new DataColumn("Quantity", typeof(int));
            dt.Columns.Add(dc);


            return dt;
        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            string orderid, pid, quantity;
            orderid = txtorderid.Text;
            pid = txtopid.Text;
            quantity = txtquantity.Text;

            try
            {

                dr = order.NewRow();
                dr[0] = int.Parse(orderid);
                dr[1] = int.Parse(pid);
                dr[2] = int.Parse(quantity);


                order.Rows.Add(dr);
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);

            }
            clear();

        }
        private void clear()
        {
            txtorderid.Text = "";
            txtopid.Text = "";
            txtquantity.Text = "";

        }

        private void txtopid_TextChanged(object sender, EventArgs e)
        {
            if (Regex.IsMatch(txtopid.Text, "[^0-9]"))
            {
                MessageBox.Show("do not enter non numeric vals");
                txtopid.Text = "";

            }

        }







        private void txtquantity_TextChanged(object sender, EventArgs e)
        {
            if (Regex.IsMatch(txtquantity.Text, "[^0-9]"))
            {
                MessageBox.Show("do not enter non numeric vals");
                txtquantity.Text = "";

            }
        }

        private void txtorderid_TextChanged(object sender, EventArgs e)
        {
            if (Regex.IsMatch(txtorderid.Text, "[^0-9]"))

            {
                MessageBox.Show("Enter valid Mobile Number");
                txtorderid.Text = "";
            }
        }
    }
}

