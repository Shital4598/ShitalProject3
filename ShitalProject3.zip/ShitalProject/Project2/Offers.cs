﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project2
{
    public partial class Offers : Form
    {
        DataTable dt;
        DataColumn dc;
        DataRow dr;
        DataTable offer;
        public Offers()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            offer = Generatetable();
            dataGridView1.DataSource = offer;
        }

        DataTable Generatetable()
        {
            dt = new DataTable("Offers");

            dc = new DataColumn("OfferId", typeof(int));
            dt.Columns.Add(dc);
            dt.PrimaryKey = new DataColumn[] { dc };

            dc = new DataColumn("Discount", typeof(int));
            dt.Columns.Add(dc);


            dc = new DataColumn("PromoSource", typeof(string));
            dt.Columns.Add(dc);


            return dt;
        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            string offerid, discount, promosource;
            offerid = txtofferid.Text;
            discount = txtdiscount.Text;
            promosource = txtpromosource.Text;


            try
            {

                dr = offer.NewRow();
                dr[0] = int.Parse(offerid);
                dr[1] = int.Parse(discount);
                dr[2] = promosource;


                offer.Rows.Add(dr);
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);

            }
            clear();

        }
        private void clear()
        {

            txtofferid.Text = "";
            txtdiscount.Text = "";
            txtpromosource.Text = "";

        }

        private void txtdiscount_TextChanged(object sender, EventArgs e)
        {
            if (Regex.IsMatch(txtdiscount.Text, "[^0-9]"))

            {
                MessageBox.Show("Enter valid Mobile Number");
                txtdiscount.Text = "";
            }
        }
    }
}
