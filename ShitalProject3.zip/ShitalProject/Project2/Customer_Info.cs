﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Project2
{
    public partial class Customer_Info : Form
    {
        DataTable dt;
        DataColumn dc;
        DataRow dr;
        DataTable custinfo;
        public Customer_Info()
        {
            InitializeComponent();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            custinfo = Generatetable();
            dataGridView1.DataSource = custinfo;

        }

        DataTable Generatetable()
        {
            dt = new DataTable("CustomerInfo");

            dc = new DataColumn("CustId", typeof(int));
            dt.Columns.Add(dc);
            dt.PrimaryKey = new DataColumn[] { dc };

            dc = new DataColumn("Dob", typeof(string));
            dt.Columns.Add(dc);

            dc = new DataColumn("PaymentOffer_Source", typeof(long));
            dt.Columns.Add(dc);


            dc = new DataColumn("OfferCashback", typeof(long));
            dt.Columns.Add(dc);


            return dt;
        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            string CustId, dob, paymentos, offercb;
            CustId = txtcustidinfo.Text;
            dob = txtdob.Text;
            paymentos = txtpayos.Text;
            offercb = txtoffercb.Text;

            try
            {

                dr = custinfo.NewRow();
                dr[0] = int.Parse(CustId);
                dr[1] = dob;
                dr[2] = long.Parse(paymentos);
                dr[3] = long.Parse(offercb);

                custinfo.Rows.Add(dr);
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);

            }
            clear();

        }
        private void clear()
        {
            txtcustidinfo.Text = "";
            txtdob.Text = "";
            txtpayos.Text = "";
            txtoffercb.Text = "";

        }

        private void txtcustidinfo_TextChanged(object sender, EventArgs e)
        {
            if (Regex.IsMatch(txtcustidinfo.Text, "[^0-9]"))
            {
                MessageBox.Show("do not enter non numeric vals");
                txtcustidinfo.Text = "";

            }

        }
    }
    
}
